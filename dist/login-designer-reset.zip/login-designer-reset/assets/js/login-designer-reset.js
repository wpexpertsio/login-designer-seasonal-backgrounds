( function ( $ ) {

	var
	container 	= $( '#customize-header-actions' ),
	button 		= $( '<input type="submit" name="login-designer-reset" id="login-designer-reset" class="button-secondary button">' ).attr( 'value', _login_designer_reset.reset );

	button.on( 'click', function ( event ) {

		event.preventDefault();

		var data = {
			wp_customize: 'on',
			action: 'customizer_reset',
			nonce: _login_designer_reset.nonce.reset
		};

		var r = confirm(_login_designer_reset.confirm);

		if ( !r ) {
			return;
		}

		$.post( ajaxurl, data, function () {
			wp.customize.state( 'saved' ).set( true );
			location.reload();
			// @todo — Make it so the Customizer refreshes, and all settings are resolved to default.
			// wp.customize.previewer.refresh();
		});
	});

	container.append( button );

} ) ( jQuery );
