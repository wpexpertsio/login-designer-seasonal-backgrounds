<?php
/**
 * Plugin Name: Login Designer — Reset
 * Plugin URI: https://logindesigner.com
 * Description: Reset and clear all Login Designer styles within the Customizer.
 * Author: Rich Tabor of ThemeBeans.com
 * Author URI: https://logindesigner.com
 * Version: 1.0.0
 * Text Domain: @@pkg.textdomain
 * Domain Path: languages
 * Requires at least: 4.7
 * Tested up to: 4.9
 *
 * Login Designer is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Login Designer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Login Designer. If not, see <http://www.gnu.org/licenses/>.
 *
 * The following  is a derivative work from the
 * Customizer Reset plugin from WPZOOM.
 *
 * @package   Login Designer Reset
 * @author    Login Designer <rich@logindesigner.com>
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 * @version   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Login_Designer_Reset' ) ) :

	/**
	 * Main Login Designer Class.
	 *
	 * @since 1.0.0
	 */
	final class Login_Designer_Reset {
		/** Singleton *************************************************************/

		/**
		 * Login_Designer_Reset The one true Login_Designer_Reset
		 *
		 * @var string $instance
		 */
		private static $instance;

		/**
		 *  WP_Customize_Manager.
		 *
		 * @var wp_customize
		 */
		private $wp_customize;

		/**
		 * Main Login_Designer_Reset Instance.
		 *
		 * Insures that only one instance of Login_Designer_Reset exists in memory at any one
		 * time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0.0
		 * @static
		 * @staticvar array $instance
		 * @uses Login_Designer_Reset::setup_constants() Setup the constants needed.
		 * @uses Login_Designer_Reset::includes() Include the required files.
		 * @uses Login_Designer_Reset::load_textdomain() load the language files.
		 * @see LOGIN_DESIGNER_RESET()
		 * @return object|Login_Designer_Reset The one true Login_Designer_Reset
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Login_Designer_Reset ) ) {
				self::$instance = new Login_Designer_Reset;
				self::$instance->constants();
				self::$instance->actions();
				self::$instance->includes();
				self::$instance->load_textdomain();
			}

			return self::$instance;
		}

		/**
		 * Throw error on object clone.
		 *
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @since 1.0.0
		 * @access protected
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'login-designer-reset' ), '1.0' );
		}

		/**
		 * Disable unserializing of the class.
		 *
		 * @since 1.0.0
		 * @access protected
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'login-designer-reset' ), '1.0' );
		}

		/**
		 * Setup plugin constants.
		 *
		 * @access private
		 * @return void
		 */
		private function constants() {
			$this->define( 'LOGIN_DESIGNER_RESET_VERSION', '1.0.0' );
			$this->define( 'LOGIN_DESIGNER_RESET_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			$this->define( 'LOGIN_DESIGNER_RESET_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
			$this->define( 'LOGIN_DESIGNER_RESET_PLUGIN_FILE', __FILE__ );
			$this->define( 'LOGIN_DESIGNER_RESET_ABSPATH', dirname( __FILE__ ) . '/' );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param  string|string $name Name of the definition.
		 * @param  string|bool   $value Default value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Include required files.
		 *
		 * @access private
		 * @since  1.0.0
		 * @return void
		 */
		private function includes() {
			require_once LOGIN_DESIGNER_RESET_PLUGIN_DIR . 'includes/class-login-designer-reset-notice.php';
		}

		/**
		 * Load the actions
		 *
		 * @return void
		 */
		public function actions() {
			add_action( 'customize_controls_print_scripts', array( $this, 'scripts' ) );
			add_action( 'wp_ajax_customizer_reset', array( $this, 'ajax_customizer_reset' ) );
			add_action( 'customize_register', array( $this, 'customize_register' ) );
		}

		/**
		 * Enqueue scripts for the Customizer.
		 *
		 * @return void
		 */
		public function scripts() {

			$js_dir  = LOGIN_DESIGNER_RESET_PLUGIN_URL . 'assets/js/';

			// Use minified libraries if SCRIPT_DEBUG is turned off.
			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			wp_enqueue_script( 'login-designer-reset', $js_dir . 'login-designer-reset' . $suffix . '.js', array( 'jquery' ), LOGIN_DESIGNER_VERSION, true );

			wp_localize_script( 'login-designer-reset', '_login_designer_reset', array(
				'reset'   	=> esc_html__( 'Reset', 'login-designer-reset' ),
				'confirm' 	=> esc_html__( 'Attention! You are attempting to reset all custom styling added to Login Designer. Please note that this action is irreversible. Proceed?', 'login-designer-reset' ),
				'nonce'   	=> array( 'reset' => wp_create_nonce( 'login-designer-reset' ) ),
			) );
		}

		/**
		 * Ajax.
		 */
		public function ajax_customizer_reset() {

			if ( ! $this->wp_customize->is_preview() ) {
				wp_send_json_error( 'not_preview' );
			}

			if ( ! check_ajax_referer( 'login-designer-reset', 'nonce', false ) ) {
				wp_send_json_error( 'invalid_nonce' );
			}

			$this->reset_customizer();

			wp_send_json_success();
		}

		/**
		 * Delete the Login Designer style options.
		 */
		public function reset_customizer() {
			delete_option( 'login_designer' );
		}

		/**
		 * Store a reference to `WP_Customize_Manager` instance
		 *
		 * @param instance|instance $wp_customize Customizer.
		 */
		public function customize_register( $wp_customize ) {
			$this->wp_customize = $wp_customize;
		}

		/**
		 * Loads the plugin language files.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return void
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'login-designer-reset', false, dirname( plugin_basename( LOGIN_DESIGNER_RESET_PLUGIN_DIR ) ) . '/languages/' );
		}
	}

endif; // End if class_exists check.


/**
 * The main function for that returns Login_Designer_Reset
 *
 * The main function responsible for returning the one true Login_Designer_Reset
 * Instance to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * Example: <?php $login_designer_reset = login_designer_reset(); ?>
 *
 * @since 1.0.0
 * @return object|Login_Designer_Reset The one true Login_Designer_Reset Instance.
 */
function login_designer_reset() {
	return Login_Designer_Reset::instance();
}

// Get Login_Designer_Reset Running.
login_designer_reset();
